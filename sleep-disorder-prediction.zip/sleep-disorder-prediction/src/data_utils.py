from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "sleep_health_demo.csv"
TARGET = "Sleep Disorder"
NUMERIC_FEATURES = ["Age", "Sleep Duration", "Quality of Sleep", "Physical Activity Level",
                    "Stress Level", "Heart Rate", "Daily Steps", "Systolic BP", "Diastolic BP"]
CATEGORICAL_FEATURES = ["Gender", "Occupation", "BMI Category"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

def load_data(path=DATA_PATH):
    df = pd.read_csv(path, keep_default_na=False)
    required = set(FEATURES + [TARGET])
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    return df[FEATURES + [TARGET]].copy()

def split_xy(df):
    return df[FEATURES], df[TARGET].astype(str)
