# Sleep Disorder Prediction — Machine Learning Demo

A reproducible machine-learning project that explores sleep-disorder classification from lifestyle and health-related features. It includes data validation, preprocessing, model comparison, evaluation metrics, and a Streamlit prediction interface.

> **Important:** The included CSV is a small synthetic demonstration dataset created for software testing. It is not clinical data and cannot support medical conclusions. This app is educational only, not a diagnostic tool. Replace the demo data with a properly licensed, documented dataset before making research claims.

## Features
- End-to-end scikit-learn pipeline with imputation, scaling, and one-hot encoding.
- Logistic Regression and Random Forest model comparison.
- Stratified train/test split and classification report.
- Streamlit interface with input validation and model output.
- Model training script and saved model artifact.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## Project layout
- `data/sleep_health_demo.csv` — synthetic demo data
- `src/data_utils.py` — schema and preprocessing helpers
- `train_model.py` — train/evaluate/export pipeline
- `app.py` — interactive prediction UI
- `models/` — generated model artifacts after training

## Input features
Age, occupation, sleep duration, sleep quality, physical activity, stress level, BMI category, blood pressure, heart rate, daily steps, and gender.

## Evaluation caveat
The demo dataset is synthetic, so test metrics only show that the code runs. They are not evidence of real-world predictive performance or clinical validity. For a credible portfolio version, document data provenance, use an appropriate real dataset, avoid leakage, and report class-wise precision/recall and limitations.

## Resume bullet (adapt after running and understanding it)
Built a scikit-learn classification pipeline with imputation, feature scaling, one-hot encoding, model comparison, and a Streamlit interface for exploring sleep-related risk patterns on a clearly labeled demo dataset.
