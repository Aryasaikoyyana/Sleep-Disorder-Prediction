from pathlib import Path
import subprocess
import sys
import joblib
import pandas as pd
import streamlit as st
from src.data_utils import FEATURES, NUMERIC_FEATURES, CATEGORICAL_FEATURES

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "sleep_disorder_pipeline.joblib"
st.set_page_config(page_title="Sleep Pattern Explorer", page_icon="🌙", layout="wide")
st.title("🌙 Sleep Pattern Explorer")
st.write("Explore how a trained demo classifier maps lifestyle inputs to a model output.")
st.warning("Educational software demo only. This is not a medical device and must not be used to diagnose, screen, or guide treatment. The bundled data is synthetic.")
if not MODEL_PATH.exists():
    st.info("The model has not been trained yet. Train it first using `python train_model.py`.")
    if st.button("Train demo model now"):
        with st.spinner("Training the demo pipeline…"):
            result = subprocess.run([sys.executable, str(ROOT / "train_model.py")], cwd=ROOT,
                                    capture_output=True, text=True)
        if result.returncode == 0:
            st.success("Demo model trained. Reloading app…")
            st.rerun()
        else:
            st.error("Training failed.")
            st.code(result.stderr or result.stdout)
    st.stop()
model = joblib.load(MODEL_PATH)
with st.form("prediction_form"):
    st.subheader("Lifestyle inputs")
    a, b, c = st.columns(3)
    with a:
        age = st.slider("Age", 18, 80,  30)
        gender = st.selectbox("Gender", ["Female", "Male"])
        occupation = st.selectbox("Occupation", ["Engineer", "Doctor", "Teacher", "Accountant", "Nurse", "Manager", "Sales Representative", "Software Engineer", "Student", "Other"])
        bmi = st.selectbox("BMI Category", ["Normal", "Normal Weight", "Overweight", "Obese"])
    with b:
        duration = st.slider("Sleep duration (hours)", 3.0, 12.0, 7.0, 0.5)
        quality = st.slider("Self-reported sleep quality (1–10)", 1, 10, 7)
        activity = st.slider("Physical activity level (minutes/day)", 0, 120, 45)
        stress = st.slider("Stress level (1–10)", 1, 10, 5)
    with c:
        systolic = st.slider("Systolic blood pressure", 85, 190, 120)
        diastolic = st.slider("Diastolic blood pressure", 50, 125, 80)
        heart = st.slider("Heart rate (bpm)", 45, 120, 72)
        steps = st.slider("Daily steps", 0, 20000, 7000, 500)
    submitted = st.form_submit_button("Explore model output", type="primary")
if submitted:
    row = pd.DataFrame([{
        "Age": age, "Sleep Duration": duration, "Quality of Sleep": quality,
        "Physical Activity Level": activity, "Stress Level": stress,
        "Heart Rate": heart, "Daily Steps": steps, "Systolic BP": systolic,
        "Diastolic BP": diastolic, "Gender": gender, "Occupation": occupation,
        "BMI Category": bmi
    }], columns=FEATURES)
    prediction = model.predict(row)[0]
    st.subheader("Demo model output")
    st.metric("Predicted class", str(prediction))
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(row)[0]
        st.write("Model class scores (not calibrated medical probabilities)")
        st.bar_chart(pd.DataFrame({"Class": model.classes_, "Score": probs}).set_index("Class"))
    st.caption("This output reflects patterns in a synthetic toy dataset. It does not estimate your actual health status.")
