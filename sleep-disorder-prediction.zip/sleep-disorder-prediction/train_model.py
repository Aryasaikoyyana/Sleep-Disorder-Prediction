from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from src.data_utils import load_data, split_xy, NUMERIC_FEATURES, CATEGORICAL_FEATURES

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

def make_preprocessor():
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    categorical = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                            ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("numeric", numeric, NUMERIC_FEATURES),
                              ("categorical", categorical, CATEGORICAL_FEATURES)])

def main():
    df = load_data()
    X, y = split_xy(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    candidates = {
        "logistic_regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "random_forest": RandomForestClassifier(n_estimators=250, min_samples_leaf=2,
                                                 class_weight="balanced", random_state=42)
    }
    results = {}
    best_name, best_model, best_score = None, None, -1
    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocessor", make_preprocessor()), ("classifier", estimator)])
        pipe.fit(X_train, y_train)
        predictions = pipe.predict(X_test)
        score = accuracy_score(y_test, predictions)
        results[name] = {
            "accuracy_demo_only": round(float(score), 4),
            "classification_report": classification_report(y_test, predictions, zero_division=0, output_dict=True),
            "confusion_matrix": confusion_matrix(y_test, predictions, labels=sorted(y.unique())).tolist(),
            "labels": sorted(y.unique())
        }
        print(f"\n{name}: accuracy on synthetic demo split = {score:.3f}")
        print(classification_report(y_test, predictions, zero_division=0))
        if score > best_score:
            best_name, best_model, best_score = name, pipe, score
    joblib.dump(best_model, MODEL_DIR / "sleep_disorder_pipeline.joblib")
    (MODEL_DIR / "evaluation.json").write_text(json.dumps({
        "best_model": best_name, "results": results,
        "warning": "Synthetic demo data only; metrics are not clinical or real-world performance."
    }, indent=2), encoding="utf-8")
    print(f"\nSaved best pipeline: {best_name}")
    print("WARNING: synthetic demo metrics are for software demonstration only.")

if __name__ == "__main__":
    main()
